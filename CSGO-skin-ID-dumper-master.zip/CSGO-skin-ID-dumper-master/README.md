# CSGO-skin-ID-dumper
Dump CSGO skin IDs directly from game files.

If you just want the CS:GO weapon/skin IDs, look in [item_index.txt](https://github.com/adamb70/CSGO-skin-ID-dumper/blob/master/item_index.txt)

## Usage
Point [SteamPath var](https://github.com/adamb70/CSGO-skin-ID-dumper/blob/master/skin_id_getter.py#L7) to CSGO base folder eg. `'C:/Program Files (x86)/Steam/steamapps/common/Counter-Strike Global Offensive/'` and run.

## TODO
Add command line usage.
